import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Slider } from "@/components/ui/slider";
import {
  ChevronDown,
  ChevronUp,
  Trash2,
  MapPin,
  TrendingDown,
  TrendingUp,
  Minus,
  Clock,
  DollarSign,
  AlertCircle,
  Wallet,
  ArrowLeftRight,
  Banknote,
  Pencil,
  Check,
  X,
  Info,
  Landmark,
  Lightbulb,
  Home,
  Building2,
} from "lucide-react";
import type { TrackedLoan, LiveRate, PropertyType } from "@shared/schema";
import { calculateRefinance, calculateMonthlyPayment, formatCurrency, amortizeBalance, monthsBetween } from "@/lib/calculations";

interface LoanTrackerProps {
  loans: TrackedLoan[];
  liveRates: LiveRate[];
  onRemove: (id: string) => void;
  onUpdate: (id: string, updates: Partial<TrackedLoan>) => void;
  maxLoans?: number;
}

// Conventional LLPA rate adjustments for occupancy type
const PROPERTY_TYPE_ADJUSTMENTS: Record<PropertyType, number> = {
  primary:    0.00,
  secondary:  0.25,
  investment: 0.75,
};

const PROPERTY_TYPE_LABELS: Record<PropertyType, string> = {
  primary:    "Primary Home",
  secondary:  "2nd Home",
  investment: "Investment",
};

const PROPERTY_TYPE_COLORS: Record<PropertyType, string> = {
  primary:    "bg-background text-foreground border",
  secondary:  "bg-amber-600 text-white border-amber-600",
  investment: "bg-red-600 text-white border-red-600",
};

// Closing cost model based on FL conventional refi loan estimate (Barrett Financial, $420K):
//   Lender Fees (underwriting):          $1,250  fixed
//   Appraisal & Services (appraisal,
//     credit report, flood, MERS, etc.): $  850  fixed
//   Title & Settlement (search $100,
//     endorsement $25, title insurance
//     $1,290, recording $100,
//     settlement $450):                  $1,965  fixed  ← full title line from estimate
//   Gov't Fees & State Taxes
//     (recording + doc stamps):          0.60%  of loan  ← FL doc stamps = 0.55% + recording
// ─────────────────────────────────────────────────────────
// Total for $420K FL loan: $4,065 + 0.60%×$420K = $6,585 ≈ actual $6,574
const CLOSING_COST_PERCENT = 0.60;
const CLOSING_COST_FIXED = 4065;

// Fixed sub-items that sum to CLOSING_COST_FIXED
const CC_LENDER_FEES      = 1250;  // underwriting fee
const CC_APPRAISAL        =  850;  // appraisal, credit report, flood cert, MERS, tax service
const CC_TITLE_SETTLEMENT = 1965;  // title search $100, endorsement $25, lender's title insurance $1,290, recording $100, settlement $450
const NEW_TERM_YEARS = 30;

// Home Equity constants
const HE_RATE_MARGIN = 2.0;   // spread above 30yr conventional
// Max CLTV varies by occupancy (primary gets more equity access)
const HE_MAX_CLTV: Record<PropertyType, number> = {
  primary:    0.90,
  secondary:  0.80,
  investment: 0.80,
};
const HELOC_DRAW_YEARS = 10;
const HELOC_REPAY_YEARS = 20;
const HE_LOAN_TERM_YEARS = 15;

type HeProduct = "heloc" | "he_loan";

function getBestConventionalRate(rates: LiveRate[]): LiveRate | null {
  return (
    rates.find((r) => r.name === "30 Yr. Fixed") ??
    rates.find((r) => r.type === "Conventional") ??
    rates[0] ??
    null
  );
}

function getRateDelta(currentRate: number, newRate: number) {
  const delta = currentRate - newRate;
  if (delta >= 0.75) return { label: "Good time to refi", color: "text-green-600 dark:text-green-400", bg: "bg-green-50 dark:bg-green-950/30 border-green-200 dark:border-green-800" };
  if (delta >= 0.25) return { label: "Marginal savings", color: "text-amber-600 dark:text-amber-400", bg: "bg-amber-50 dark:bg-amber-950/30 border-amber-200 dark:border-amber-800" };
  return { label: "Rates similar", color: "text-muted-foreground", bg: "bg-muted/40 border-border" };
}

type BestOption = {
  type: "rate_term" | "second_lien" | "hold";
  label: string;
  reason: string;
  badgeClass: string;
  cardBg: string;
  Icon: React.ElementType;
};

function getBestOption(loan: TrackedLoan, adjustedTodayRate: number, propertyType: PropertyType): BestOption {
  const { loanBalance, estimatedHomeValue: homeValue, currentRate } = loan;
  const rateDelta = currentRate - adjustedTodayRate; // positive = their rate is above today's market
  const maxCltv = HE_MAX_CLTV[propertyType];

  const hasSecondLienEquity = homeValue > 0 && homeValue * maxCltv - loanBalance > 10_000;

  // They have a below-market rate — never touch that mortgage
  if (rateDelta <= 0) {
    if (hasSecondLienEquity) {
      return {
        type: "second_lien",
        label: "2nd Lien Home Equity",
        reason: `Your ${currentRate.toFixed(2)}% rate is below today's market — protect it and tap equity via a 2nd lien instead`,
        badgeClass: "bg-yellow-100 dark:bg-yellow-900/40 text-yellow-800 dark:text-yellow-200 border-yellow-300 dark:border-yellow-700",
        cardBg: "bg-yellow-50 dark:bg-yellow-950/30 border-yellow-200 dark:border-yellow-800",
        Icon: Landmark,
      };
    }
    return {
      type: "hold",
      label: "Hold — no action needed",
      reason: `Your ${currentRate.toFixed(2)}% rate is at or below today's market and equity is limited — wait for conditions to improve`,
      badgeClass: "bg-muted text-muted-foreground border",
      cardBg: "bg-muted/40 border-border",
      Icon: Home,
    };
  }

  // Strong rate-drop opportunity (≥ 0.75%)
  if (rateDelta >= 0.75) {
    return {
      type: "rate_term",
      label: "Rate & Term Refinance",
      reason: `${rateDelta.toFixed(2)}% rate drop from ${currentRate.toFixed(2)}% → ${adjustedTodayRate.toFixed(2)}% — strongest savings opportunity right now`,
      badgeClass: "bg-blue-100 dark:bg-blue-900/40 text-blue-800 dark:text-blue-200 border-blue-300 dark:border-blue-700",
      cardBg: "bg-blue-50 dark:bg-blue-950/30 border-blue-200 dark:border-blue-800",
      Icon: ArrowLeftRight,
    };
  }

  // Marginal rate drop (0–0.75%) — prefer 2nd lien if equity exists
  if (hasSecondLienEquity) {
    return {
      type: "second_lien",
      label: "2nd Lien Home Equity",
      reason: `Only a modest ${rateDelta.toFixed(2)}% rate gap — a 2nd lien lets you tap equity while keeping your current rate`,
      badgeClass: "bg-yellow-100 dark:bg-yellow-900/40 text-yellow-800 dark:text-yellow-200 border-yellow-300 dark:border-yellow-700",
      cardBg: "bg-yellow-50 dark:bg-yellow-950/30 border-yellow-200 dark:border-yellow-800",
      Icon: Landmark,
    };
  }

  // Rate is above market but no equity options
  return {
    type: "rate_term",
    label: "Rate & Term Refinance",
    reason: `${rateDelta.toFixed(2)}% rate drop available — only viable option since equity is limited`,
    badgeClass: "bg-blue-100 dark:bg-blue-900/40 text-blue-800 dark:text-blue-200 border-blue-300 dark:border-blue-700",
    cardBg: "bg-blue-50 dark:bg-blue-950/30 border-blue-200 dark:border-blue-800",
    Icon: ArrowLeftRight,
  };
}

function RateCompare({ current, today }: { current: number; today: number }) {
  const delta = current - today;
  const positive = delta > 0;
  return (
    <div className="flex items-center gap-2 text-sm flex-wrap">
      <span className="font-bold text-base">{current.toFixed(3)}%</span>
      <span className="text-muted-foreground">current</span>
      <span className="text-muted-foreground">→</span>
      <span className={`font-bold text-base ${positive ? "text-green-600 dark:text-green-400" : "text-muted-foreground"}`}>
        {today.toFixed(2)}%
      </span>
      <span className="text-muted-foreground">today</span>
      {positive ? (
        <span className="flex items-center gap-0.5 text-xs text-green-600 dark:text-green-400 font-medium">
          <TrendingDown className="h-3 w-3" />
          {delta.toFixed(2)}% lower
        </span>
      ) : delta < 0 ? (
        <span className="flex items-center gap-0.5 text-xs text-red-500 font-medium">
          <TrendingUp className="h-3 w-3" />
          {Math.abs(delta).toFixed(2)}% higher
        </span>
      ) : (
        <span className="flex items-center gap-0.5 text-xs text-muted-foreground">
          <Minus className="h-3 w-3" />
          Same
        </span>
      )}
    </div>
  );
}

const CASH_OUT_MAX_LTV = 0.75;

function CashOutSection({
  loan,
  newRate,
  homeValue,
  onChangeHomeValue,
}: {
  loan: TrackedLoan;
  newRate: LiveRate;
  homeValue: number;
  onChangeHomeValue: (v: number) => void;
}) {
  const [editing, setEditing] = useState(false);
  const [editInput, setEditInput] = useState(String(Math.round(homeValue)));

  // Back-calculate max loan so that (loan + closingCosts) ≤ 75% LTV
  // loan * (1 + pct/100) + fixed = homeValue * 0.75
  const maxNewLoan = Math.floor(
    (homeValue * CASH_OUT_MAX_LTV - CLOSING_COST_FIXED) / (1 + CLOSING_COST_PERCENT / 100)
  );
  const currentLTV = homeValue > 0 ? loan.loanBalance / homeValue : 1;
  const isLTVTooHigh = currentLTV >= CASH_OUT_MAX_LTV;

  const [newLoanAmount, setNewLoanAmount] = useState(
    isLTVTooHigh ? loan.loanBalance : maxNewLoan
  );

  const clampedLoan = Math.min(Math.max(newLoanAmount, loan.loanBalance), maxNewLoan);
  const cashOut = Math.max(0, clampedLoan - loan.loanBalance);

  const closingCosts = (clampedLoan * CLOSING_COST_PERCENT) / 100 + CLOSING_COST_FIXED;
  const finalLoanWithCosts = clampedLoan + closingCosts;
  const newMonthlyPI = calculateMonthlyPayment(finalLoanWithCosts, newRate.rate, NEW_TERM_YEARS);
  const currentMonthlyPI = loan.currentPI;
  const newLTV = homeValue > 0 ? (finalLoanWithCosts / homeValue) * 100 : 0;

  function commitEdit() {
    const parsed = parseFloat(editInput.replace(/[^0-9.]/g, ""));
    if (!isNaN(parsed) && parsed > 0) {
      const newMax = Math.floor(
        (parsed * CASH_OUT_MAX_LTV - CLOSING_COST_FIXED) / (1 + CLOSING_COST_PERCENT / 100)
      );
      onChangeHomeValue(parsed);
      setNewLoanAmount(newMax);
    }
    setEditing(false);
  }

  if (isLTVTooHigh) {
    return (
      <div className="rounded-md border border-red-300 dark:border-red-700 bg-red-50 dark:bg-red-950/30 p-4 flex items-start gap-3">
        <AlertCircle className="h-5 w-5 text-red-600 dark:text-red-400 flex-shrink-0 mt-0.5" />
        <div className="space-y-1">
          <p className="font-semibold text-sm text-red-700 dark:text-red-400">
            1st lien cash-out refinance is not possible due to LTV limits
          </p>
          <p className="text-sm text-red-600 dark:text-red-500">
            Your current LTV is <strong>{(currentLTV * 100).toFixed(1)}%</strong>, which exceeds the 75% maximum
            allowed for cash-out refinancing. You would need to pay down your balance or wait for your home value
            to increase before a cash-out refi is available.
          </p>
          <div className="flex items-start gap-1 mt-2 text-xs text-red-500 dark:text-red-500">
            <Info className="h-3 w-3 mt-0.5 flex-shrink-0" />
            <span>
              Home value used: {formatCurrency(homeValue)} (AI estimate from statement analysis).{" "}
              <button
                className="underline hover:no-underline"
                onClick={() => setEditing(true)}
              >
                Edit value
              </button>
            </span>
          </div>
          {editing && (
            <div className="flex items-center gap-2 mt-2">
              <span className="text-sm text-red-700 dark:text-red-400">$</span>
              <input
                type="text"
                className="border rounded px-2 py-1 text-sm w-36 bg-background text-foreground"
                value={editInput}
                onChange={(e) => setEditInput(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter") commitEdit(); if (e.key === "Escape") setEditing(false); }}
                autoFocus
              />
              <Button size="sm" variant="ghost" onClick={commitEdit} className="h-7 px-2"><Check className="h-3 w-3" /></Button>
              <Button size="sm" variant="ghost" onClick={() => setEditing(false)} className="h-7 px-2"><X className="h-3 w-3" /></Button>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Home value row */}
      <div className="flex items-center justify-between p-3 rounded-md border bg-muted/30 flex-wrap gap-2">
        <div className="space-y-0.5">
          <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Est. Home Value</p>
          {editing ? (
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium">$</span>
              <input
                type="text"
                className="border rounded px-2 py-1 text-sm w-36 bg-background text-foreground"
                value={editInput}
                onChange={(e) => setEditInput(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter") commitEdit(); if (e.key === "Escape") setEditing(false); }}
                autoFocus
              />
              <Button size="sm" variant="ghost" onClick={commitEdit} className="h-7 px-2"><Check className="h-3 w-3" /></Button>
              <Button size="sm" variant="ghost" onClick={() => setEditing(false)} className="h-7 px-2"><X className="h-3 w-3" /></Button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <span className="font-bold text-lg">{formatCurrency(homeValue)}</span>
              <button
                onClick={() => { setEditInput(String(Math.round(homeValue))); setEditing(true); }}
                className="text-muted-foreground hover:text-foreground transition-colors"
                data-testid={`button-edit-home-value-${loan.id}`}
              >
                <Pencil className="h-3.5 w-3.5" />
              </button>
            </div>
          )}
          <p className="text-xs text-amber-600 dark:text-amber-400">AI estimate — not from live market data · edit to use your actual value</p>
        </div>
        <div className="text-right space-y-0.5">
          <p className="text-xs text-muted-foreground">Current LTV</p>
          <p className="font-bold text-lg">{(currentLTV * 100).toFixed(1)}%</p>
          <p className="text-xs text-muted-foreground">75% max for cash-out</p>
        </div>
      </div>

      {/* Slider */}
      <div className="space-y-3 p-3 rounded-md border bg-background">
        <div className="flex items-baseline justify-between flex-wrap gap-1">
          <div>
            <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">New Loan Amount</p>
            <p className="font-bold text-2xl">{formatCurrency(finalLoanWithCosts)}</p>
          </div>
          <div className="text-right space-y-1">
            <div>
              <p className="text-xs text-muted-foreground">Cash you'd receive</p>
              <p className="font-bold text-xl text-green-600 dark:text-green-400">{formatCurrency(cashOut)}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Combined LTV</p>
              <p className={`font-semibold text-sm ${newLTV > CASH_OUT_MAX_LTV * 100 ? "text-red-500" : "text-foreground"}`}>
                {newLTV.toFixed(1)}% <span className="text-xs font-normal text-muted-foreground">of {(CASH_OUT_MAX_LTV * 100).toFixed(0)}% max</span>
              </p>
            </div>
          </div>
        </div>

        <Slider
          min={loan.loanBalance}
          max={maxNewLoan}
          step={1000}
          value={[clampedLoan]}
          onValueChange={([val]) => setNewLoanAmount(val)}
          data-testid={`slider-cash-out-${loan.id}`}
        />
      </div>

      {/* Scenario stats */}
      <div className="grid sm:grid-cols-2 gap-4">
        <div className="rounded-lg border bg-muted/30 p-4 space-y-2">
          <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Current Loan</p>
          <div className="flex justify-between items-baseline">
            <span className="text-sm text-muted-foreground">Monthly P&I</span>
            <span className="font-semibold">{formatCurrency(currentMonthlyPI)}</span>
          </div>
          <div className="flex justify-between items-baseline">
            <span className="text-sm text-muted-foreground">Loan Balance</span>
            <span className="font-semibold">{formatCurrency(loan.loanBalance)}</span>
          </div>
          <div className="flex justify-between items-baseline">
            <span className="text-sm text-muted-foreground">LTV</span>
            <span className="font-semibold">{(currentLTV * 100).toFixed(1)}%</span>
          </div>
        </div>

        <div className="rounded-lg border bg-green-50/50 dark:bg-green-950/20 border-green-200 dark:border-green-800 p-4 space-y-2">
          <div className="flex items-center justify-between flex-wrap gap-1">
            <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">After Cash-Out</p>
            <Badge variant="outline" className="text-xs">{newRate.name} · {newRate.type}</Badge>
          </div>
          <div className="flex justify-between items-baseline">
            <span className="text-sm text-muted-foreground">New Rate</span>
            <span className="font-bold text-lg">{newRate.rate.toFixed(2)}%</span>
          </div>
          <div className="flex justify-between items-baseline">
            <span className="text-sm text-muted-foreground">New Monthly P&I</span>
            <span className="font-semibold">{formatCurrency(newMonthlyPI)}</span>
          </div>
          <div className="flex justify-between items-baseline">
            <span className="text-sm text-muted-foreground">New Loan Amount</span>
            <span className="font-semibold">
              {formatCurrency(finalLoanWithCosts)}
              <span className="ml-1 text-xs text-muted-foreground font-normal">(incl. closing costs)</span>
            </span>
          </div>
          <div className="flex justify-between items-baseline">
            <span className="text-sm text-muted-foreground">New LTV</span>
            <span className={`font-semibold ${newLTV > 75 ? "text-amber-600 dark:text-amber-400" : ""}`}>
              {newLTV.toFixed(1)}%
            </span>
          </div>
          <div className="flex justify-between items-baseline">
            <span className="text-sm text-muted-foreground">Est. Closing Costs</span>
            <span className="font-semibold">{formatCurrency(closingCosts)}</span>
          </div>
        </div>
      </div>

    </div>
  );
}

function HomeEquitySection({
  loan,
  heRate,
  rateAdjustment,
  propertyType,
  homeValue,
  onChangeHomeValue,
}: {
  loan: TrackedLoan;
  heRate: number;
  rateAdjustment: number;
  propertyType: PropertyType;
  homeValue: number;
  onChangeHomeValue: (v: number) => void;
}) {
  const [product, setProduct] = useState<HeProduct>("heloc");
  const [borrowAmount, setBorrowAmount] = useState(Infinity);
  const [editing, setEditing] = useState(false);
  const [editInput, setEditInput] = useState(String(Math.round(homeValue)));

  const maxCltv = HE_MAX_CLTV[propertyType];
  const maxHEAmount = Math.max(0, Math.floor(homeValue * maxCltv - loan.loanBalance));
  const clampedBorrow = Math.min(Math.max(borrowAmount, 0), maxHEAmount);
  const cltv = homeValue > 0 ? (loan.loanBalance + clampedBorrow) / homeValue : 1;
  const notEnoughEquity = maxHEAmount <= 0;

  function commitEdit() {
    const parsed = parseFloat(editInput.replace(/[^0-9.]/g, ""));
    if (!isNaN(parsed) && parsed > 0) {
      onChangeHomeValue(parsed);
      setBorrowAmount(Infinity);
    }
    setEditing(false);
  }

  // HELOC
  const helocInterestOnly = clampedBorrow > 0 ? clampedBorrow * (heRate / 100 / 12) : 0;
  const helocRepayment = calculateMonthlyPayment(clampedBorrow, heRate, HELOC_REPAY_YEARS);

  // Fixed HE Loan
  const heLoanMonthly = calculateMonthlyPayment(clampedBorrow, heRate, HE_LOAN_TERM_YEARS);
  const heLoanTotalInterest = clampedBorrow > 0 ? heLoanMonthly * HE_LOAN_TERM_YEARS * 12 - clampedBorrow : 0;

  if (notEnoughEquity) {
    return (
      <div className="rounded-md border border-red-300 dark:border-red-700 bg-red-50 dark:bg-red-950/30 p-4 flex items-start gap-3">
        <AlertCircle className="h-5 w-5 text-red-600 dark:text-red-400 flex-shrink-0 mt-0.5" />
        <div className="space-y-1">
          <p className="font-semibold text-sm text-red-700 dark:text-red-400">
            Not enough equity for a 2nd lien product
          </p>
          <p className="text-sm text-red-600 dark:text-red-500">
            Your current LTV is <strong>{homeValue > 0 ? ((loan.loanBalance / homeValue) * 100).toFixed(1) : "?"}%</strong>, leaving no room
            below the {(maxCltv * 100).toFixed(0)}% CLTV limit for a {PROPERTY_TYPE_LABELS[propertyType].toLowerCase()}.
            Pay down your balance or wait for your home value to increase.
          </p>
          <div className="flex items-start gap-1 mt-2 text-xs text-red-500 dark:text-red-500">
            <Info className="h-3 w-3 mt-0.5 flex-shrink-0" />
            <span>
              Home value used: {formatCurrency(homeValue)} (AI estimate).{" "}
              <button className="underline hover:no-underline" onClick={() => setEditing(true)}>
                Edit value
              </button>
            </span>
          </div>
          {editing && (
            <div className="flex items-center gap-2 mt-2">
              <span className="text-sm text-red-700 dark:text-red-400">$</span>
              <input
                type="text"
                className="border rounded px-2 py-1 text-sm w-36 bg-background text-foreground"
                value={editInput}
                onChange={(e) => setEditInput(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter") commitEdit(); if (e.key === "Escape") setEditing(false); }}
                autoFocus
              />
              <Button size="sm" variant="ghost" onClick={commitEdit} className="h-7 px-2"><Check className="h-3 w-3" /></Button>
              <Button size="sm" variant="ghost" onClick={() => setEditing(false)} className="h-7 px-2"><X className="h-3 w-3" /></Button>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Rate + home value row */}
      <div className="grid sm:grid-cols-2 gap-3">
        <div className="flex items-center justify-between p-3 rounded-md border bg-muted/30 flex-wrap gap-2">
          <div className="space-y-0.5">
            <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">2nd Lien Rate</p>
            <p className="font-bold text-xl">{heRate.toFixed(2)}%</p>
            {rateAdjustment > 0 ? (
              <p className="text-xs text-muted-foreground">
                30yr ({(heRate - HE_RATE_MARGIN - rateAdjustment).toFixed(2)}%)
                {" + "}{rateAdjustment.toFixed(2)}% occupancy
                {" + "}{HE_RATE_MARGIN.toFixed(2)}% 2nd-lien margin
              </p>
            ) : (
              <p className="text-xs text-muted-foreground">30yr ({(heRate - HE_RATE_MARGIN).toFixed(2)}%) + {HE_RATE_MARGIN.toFixed(2)}% 2nd-lien margin</p>
            )}
          </div>
          <div className="text-right space-y-0.5">
            <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Max Available</p>
            <p className="font-bold text-xl">{formatCurrency(maxHEAmount)}</p>
            <p className="text-xs text-muted-foreground">{(maxCltv * 100).toFixed(0)}% CLTV limit</p>
          </div>
        </div>

        <div className="flex items-center justify-between p-3 rounded-md border bg-muted/30 flex-wrap gap-2">
          <div className="space-y-0.5">
            <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Est. Home Value</p>
            {editing ? (
              <div className="flex items-center gap-1">
                <span className="text-sm">$</span>
                <input
                  type="text"
                  className="border rounded px-2 py-1 text-sm w-28 bg-background text-foreground"
                  value={editInput}
                  onChange={(e) => setEditInput(e.target.value)}
                  onKeyDown={(e) => { if (e.key === "Enter") commitEdit(); if (e.key === "Escape") setEditing(false); }}
                  autoFocus
                />
                <Button size="sm" variant="ghost" onClick={commitEdit} className="h-7 px-1"><Check className="h-3 w-3" /></Button>
                <Button size="sm" variant="ghost" onClick={() => setEditing(false)} className="h-7 px-1"><X className="h-3 w-3" /></Button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <span className="font-bold text-xl">{formatCurrency(homeValue)}</span>
                <button
                  onClick={() => { setEditInput(String(Math.round(homeValue))); setEditing(true); }}
                  className="text-muted-foreground hover:text-foreground transition-colors"
                >
                  <Pencil className="h-3.5 w-3.5" />
                </button>
              </div>
            )}
            <p className="text-xs text-amber-600 dark:text-amber-400">AI estimate · edit to refine</p>
          </div>
          <div className="text-right space-y-0.5">
            <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Current CLTV</p>
            <p className="font-bold text-xl">{homeValue > 0 ? ((loan.loanBalance / homeValue) * 100).toFixed(1) : "—"}%</p>
            <p className="text-xs text-muted-foreground">1st lien only</p>
          </div>
        </div>
      </div>

      {(
        <>
          {/* Product toggle */}
          <div className="flex rounded-md border overflow-hidden text-sm font-medium">
            <button
              className={`flex-1 py-2 px-4 transition-colors ${product === "heloc" ? "bg-yellow-400 text-yellow-900 font-semibold" : "bg-background text-muted-foreground hover:bg-muted"}`}
              onClick={() => setProduct("heloc")}
              data-testid="button-product-heloc"
            >
              HELOC <span className="text-xs font-normal opacity-80">(variable, interest-only draw)</span>
            </button>
            <button
              className={`flex-1 py-2 px-4 transition-colors ${product === "he_loan" ? "bg-yellow-400 text-yellow-900 font-semibold" : "bg-background text-muted-foreground hover:bg-muted"}`}
              onClick={() => setProduct("he_loan")}
              data-testid="button-product-he-loan"
            >
              Fixed HE Loan <span className="text-xs font-normal opacity-80">({HE_LOAN_TERM_YEARS}-yr fully amortizing)</span>
            </button>
          </div>

          {/* Borrow amount slider */}
          <div className="space-y-3 p-3 rounded-md border bg-background">
            <div className="flex items-baseline justify-between flex-wrap gap-1">
              <div>
                <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">
                  {product === "heloc" ? "Line Amount" : "Loan Amount"}
                </p>
                <p className="font-bold text-2xl">{formatCurrency(clampedBorrow)}</p>
              </div>
              <div className="text-right">
                <p className="text-xs text-muted-foreground">Combined LTV after</p>
                <p className={`font-bold text-lg ${cltv > maxCltv ? "text-red-500" : "text-foreground"}`}>
                  {(cltv * 100).toFixed(1)}%
                </p>
              </div>
            </div>
            <Slider
              min={0}
              max={maxHEAmount}
              step={1000}
              value={[clampedBorrow]}
              onValueChange={([val]) => setBorrowAmount(val)}
              data-testid={`slider-he-amount-${loan.id}`}
            />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>$0</span>
              <span>Max {formatCurrency(maxHEAmount)}</span>
            </div>
          </div>

          {/* Payment panels — only show when amount > 0 */}
          {clampedBorrow > 0 && (
            product === "heloc" ? (
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="rounded-lg border bg-yellow-50/50 dark:bg-yellow-950/20 border-yellow-200 dark:border-yellow-700 p-4 space-y-2">
                  <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Draw Period · {HELOC_DRAW_YEARS} yrs</p>
                  <p className="text-xs text-muted-foreground">Interest-only payments on amount drawn</p>
                  <div className="flex justify-between items-baseline mt-1">
                    <span className="text-sm text-muted-foreground">Monthly interest</span>
                    <span className="font-bold text-xl">{formatCurrency(helocInterestOnly)}</span>
                  </div>
                  <div className="flex justify-between items-baseline">
                    <span className="text-sm text-muted-foreground">Rate</span>
                    <span className="font-semibold">{heRate.toFixed(2)}%</span>
                  </div>
                  <div className="flex justify-between items-baseline">
                    <span className="text-sm text-muted-foreground">Principal owed at end</span>
                    <span className="font-semibold">{formatCurrency(clampedBorrow)}</span>
                  </div>
                </div>
                <div className="rounded-lg border bg-yellow-50/50 dark:bg-yellow-950/20 border-yellow-200 dark:border-yellow-700 p-4 space-y-2">
                  <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Repayment Period · {HELOC_REPAY_YEARS} yrs</p>
                  <p className="text-xs text-muted-foreground">Fully amortizing P&I on the full balance</p>
                  <div className="flex justify-between items-baseline mt-1">
                    <span className="text-sm text-muted-foreground">Monthly P&I</span>
                    <span className="font-bold text-xl">{formatCurrency(helocRepayment)}</span>
                  </div>
                  <div className="flex justify-between items-baseline">
                    <span className="text-sm text-muted-foreground">1st lien P&I</span>
                    <span className="font-semibold">{formatCurrency(loan.currentPI)}</span>
                  </div>
                  <div className="flex justify-between items-baseline border-t pt-2 mt-1">
                    <span className="text-sm font-medium">Combined monthly</span>
                    <span className="font-bold">{formatCurrency(loan.currentPI + helocRepayment)}</span>
                  </div>
                </div>
              </div>
            ) : (
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="rounded-lg border bg-muted/30 p-4 space-y-2">
                  <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Current 1st Mortgage</p>
                  <div className="flex justify-between items-baseline">
                    <span className="text-sm text-muted-foreground">Monthly P&I</span>
                    <span className="font-semibold">{formatCurrency(loan.currentPI)}</span>
                  </div>
                  <div className="flex justify-between items-baseline">
                    <span className="text-sm text-muted-foreground">Balance</span>
                    <span className="font-semibold">{formatCurrency(loan.loanBalance)}</span>
                  </div>
                  <div className="flex justify-between items-baseline">
                    <span className="text-sm text-muted-foreground">Rate</span>
                    <span className="font-semibold">{loan.currentRate.toFixed(3)}%</span>
                  </div>
                </div>
                <div className="rounded-lg border bg-yellow-50/50 dark:bg-yellow-950/20 border-yellow-200 dark:border-yellow-700 p-4 space-y-2">
                  <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Fixed HE Loan · {HE_LOAN_TERM_YEARS} yrs</p>
                  <div className="flex justify-between items-baseline">
                    <span className="text-sm text-muted-foreground">Monthly P&I</span>
                    <span className="font-bold text-xl">{formatCurrency(heLoanMonthly)}</span>
                  </div>
                  <div className="flex justify-between items-baseline">
                    <span className="text-sm text-muted-foreground">Rate</span>
                    <span className="font-semibold">{heRate.toFixed(2)}%</span>
                  </div>
                  <div className="flex justify-between items-baseline">
                    <span className="text-sm text-muted-foreground">Total interest</span>
                    <span className="font-semibold">{formatCurrency(heLoanTotalInterest)}</span>
                  </div>
                  <div className="flex justify-between items-baseline border-t pt-2 mt-1">
                    <span className="text-sm font-medium">Combined monthly</span>
                    <span className="font-bold">{formatCurrency(loan.currentPI + heLoanMonthly)}</span>
                  </div>
                </div>
              </div>
            )
          )}

        </>
      )}

    </div>
  );
}

function ExpandedView({ loan, newRate, rateAdjustment, onUpdate }: {
  loan: TrackedLoan;
  newRate: LiveRate;
  rateAdjustment: number;
  onUpdate: (updates: Partial<TrackedLoan>) => void;
}) {
  const [rollIn, setRollIn] = useState(true);
  const [homeValue, setHomeValue] = useState(loan.estimatedHomeValue);
  const [editingBalance, setEditingBalance] = useState(false);
  const [balanceInput, setBalanceInput] = useState("");
  const [showCostBreakdown, setShowCostBreakdown] = useState(false);

  // How many months of principal paydown are reflected in the current balance
  const monthsAmortized = monthsBetween(loan.balanceAsOf ?? loan.addedAt);

  function commitBalance() {
    const raw = balanceInput.replace(/[^0-9.]/g, "");
    const val = parseFloat(raw);
    if (!isNaN(val) && val > 0) {
      onUpdate({ loanBalance: Math.round(val), balanceAsOf: new Date().toISOString() });
    }
    setEditingBalance(false);
  }

  // Persist home value changes back to tracker so the "Best option" badge updates
  function updateHomeValue(v: number) {
    setHomeValue(v);
    onUpdate({ estimatedHomeValue: v });
  }

  // Apply occupancy adjustment to the live rate
  const adjustedRate: LiveRate = {
    ...newRate,
    rate: parseFloat((newRate.rate + rateAdjustment).toFixed(3)),
  };
  const heRate = parseFloat((adjustedRate.rate + HE_RATE_MARGIN).toFixed(3));

  const result = calculateRefinance({
    appraisedValue: homeValue,
    loanBalance: loan.loanBalance,
    currentInterestRate: loan.currentRate,
    newInterestRate: adjustedRate.rate,
    currentTermRemainingYears: Math.min(30, Math.max(1, Math.round(loan.estimatedRemainingYears))),
    newLoanTermYears: NEW_TERM_YEARS,
    closingCostsPercent: CLOSING_COST_PERCENT,
    closingCostsFixed: CLOSING_COST_FIXED,
    includeClosingCostsInLoan: rollIn,
    refinanceType: "rate_and_term",
  });

  const saving = result.monthlySavings > 0;

  return (
    <div className="mt-4 pt-4 border-t space-y-4">


      {/* ── Rate & Term Refinance ── */}
      <div className="rounded-lg border border-blue-200 dark:border-blue-800 overflow-hidden">
        <div className="flex items-center gap-2 px-4 py-3 bg-blue-50 dark:bg-blue-950/50 border-b border-blue-200 dark:border-blue-800">
          <ArrowLeftRight className="h-4 w-4 text-blue-600 dark:text-blue-400 flex-shrink-0" />
          <span className="font-semibold text-blue-900 dark:text-blue-100">Rate &amp; Term Refinance</span>
          <span className="text-xs text-blue-500 dark:text-blue-400 ml-1 hidden sm:inline">Lower your payment without taking cash out</span>
        </div>

        <div className="p-4 space-y-4">

      {/* Two-column comparison */}
      <div className="grid sm:grid-cols-2 gap-4">
        {/* Current Loan */}
        <div className="rounded-lg border bg-muted/30 p-4 space-y-3">
          <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Current Loan</p>
          <div className="space-y-2">
            <div className="flex justify-between items-baseline">
              <span className="text-sm text-muted-foreground">Interest Rate</span>
              <span className="font-bold text-lg">{loan.currentRate.toFixed(3)}%</span>
            </div>
            <div className="flex justify-between items-baseline">
              <span className="text-sm text-muted-foreground">Monthly P&I</span>
              <span className="font-semibold">{formatCurrency(loan.currentPI)}</span>
            </div>
            <div className="flex justify-between items-start gap-2">
              <span className="text-sm text-muted-foreground pt-0.5">Loan Balance</span>
              <div className="text-right">
                {editingBalance ? (
                  <div className="flex items-center gap-1">
                    <span className="text-sm">$</span>
                    <input
                      type="text"
                      className="border rounded px-2 py-0.5 text-sm w-28 bg-background text-foreground text-right"
                      value={balanceInput}
                      onChange={(e) => setBalanceInput(e.target.value)}
                      onKeyDown={(e) => { if (e.key === "Enter") commitBalance(); if (e.key === "Escape") setEditingBalance(false); }}
                      autoFocus
                    />
                    <Button size="sm" variant="ghost" onClick={commitBalance} className="h-6 px-1"><Check className="h-3 w-3" /></Button>
                    <Button size="sm" variant="ghost" onClick={() => setEditingBalance(false)} className="h-6 px-1"><X className="h-3 w-3" /></Button>
                  </div>
                ) : (
                  <div className="flex items-center gap-1.5 justify-end">
                    <span className="font-semibold">{formatCurrency(loan.loanBalance)}</span>
                    <button
                      onClick={() => { setBalanceInput(String(loan.loanBalance)); setEditingBalance(true); }}
                      className="text-muted-foreground hover:text-foreground transition-colors"
                      title="Adjust balance"
                    >
                      <Pencil className="h-3 w-3" />
                    </button>
                  </div>
                )}
                {monthsAmortized > 0 && !editingBalance && (
                  <p className="text-xs text-blue-500 dark:text-blue-400 mt-0.5">
                    ~{monthsAmortized}mo paydown applied
                  </p>
                )}
              </div>
            </div>
            <div className="flex justify-between items-baseline">
              <span className="text-sm text-muted-foreground">Remaining Term</span>
              <span className="font-semibold">~{Math.round(loan.estimatedRemainingYears)} yrs</span>
            </div>
          </div>
        </div>

        {/* Refinance Scenario */}
        <div className={`rounded-lg border p-4 space-y-3 ${saving ? "bg-green-50/50 dark:bg-green-950/20 border-green-200 dark:border-green-800" : "bg-muted/30"}`}>
          <div className="flex items-center justify-between flex-wrap gap-1">
            <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
              Refi Scenario
            </p>
            <Badge variant="outline" className="text-xs">
              {newRate.name} · {newRate.type}
            </Badge>
          </div>
          <div className="space-y-2">
            <div className="flex justify-between items-baseline">
              <span className="text-sm text-muted-foreground">New Rate</span>
              <span className="font-bold text-lg">{adjustedRate.rate.toFixed(2)}%</span>
            </div>
            <div className="flex justify-between items-baseline">
              <span className="text-sm text-muted-foreground">New Monthly P&I</span>
              <span className="font-semibold">{formatCurrency(result.monthlyPaymentNew)}</span>
            </div>
            <div className="flex justify-between items-baseline">
              <span className="text-sm text-muted-foreground">New Loan Amount</span>
              <span className="font-semibold">
                {formatCurrency(result.newLoanAmount)}
                {rollIn && (
                  <span className="ml-1 text-xs text-muted-foreground font-normal">
                    (incl. closing costs)
                  </span>
                )}
              </span>
            </div>
            <div className="flex items-center justify-between gap-2 py-0.5 border-t border-dashed">
              <Label htmlFor={`roll-in-${loan.id}`} className="text-sm text-muted-foreground cursor-pointer select-none">
                Roll closing costs into loan
              </Label>
              <Switch
                id={`roll-in-${loan.id}`}
                checked={rollIn}
                onCheckedChange={setRollIn}
                data-testid={`switch-roll-in-${loan.id}`}
              />
            </div>
            {/* Est. Closing Costs — expandable breakdown */}
            <div>
              <button
                className="w-full flex justify-between items-center group"
                onClick={() => setShowCostBreakdown(v => !v)}
              >
                <span className="text-sm text-muted-foreground flex items-center gap-1">
                  Est. Closing Costs
                  {showCostBreakdown
                    ? <ChevronUp className="h-3 w-3 opacity-60" />
                    : <ChevronDown className="h-3 w-3 opacity-60" />}
                </span>
                <span className="font-semibold">{formatCurrency(result.totalClosingCosts)}</span>
              </button>
              {showCostBreakdown && (
                <div className="mt-2 rounded-md border bg-muted/40 p-3 space-y-1.5 text-xs">
                  <p className="text-muted-foreground font-medium uppercase tracking-wide mb-2">Cost breakdown</p>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Lender Fees (underwriting)</span>
                    <span className="font-medium tabular-nums">{formatCurrency(CC_LENDER_FEES)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Appraisal &amp; Services</span>
                    <span className="font-medium tabular-nums">{formatCurrency(CC_APPRAISAL)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Title &amp; Settlement</span>
                    <span className="font-medium tabular-nums">{formatCurrency(CC_TITLE_SETTLEMENT)}</span>
                  </div>
                  <div className="flex justify-between border-t pt-1.5 mt-1">
                    <span className="text-muted-foreground">Gov't Fees &amp; State Taxes</span>
                    <span className="font-medium tabular-nums">{formatCurrency(result.totalClosingCosts - CC_LENDER_FEES - CC_APPRAISAL - CC_TITLE_SETTLEMENT)}</span>
                  </div>
                  <p className="text-muted-foreground/70 text-[10px] pt-1 border-t">
                    Fixed fees based on FL conventional refi avg. Gov't fees include recording &amp; doc stamps (0.60% of loan; FL doc stamps alone = 0.55%). Actual costs vary by state and lender.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Out-of-pocket callout when NOT rolling in */}
      {!rollIn && (
        <div className="flex items-start gap-2 text-sm bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800 text-blue-800 dark:text-blue-300 rounded-md p-3">
          <Wallet className="h-4 w-4 mt-0.5 flex-shrink-0" />
          <span>
            You would pay <strong>{formatCurrency(result.totalClosingCosts)}</strong> out of pocket at closing.
            Your new loan balance stays at <strong>{formatCurrency(result.newLoanAmount)}</strong> — the same as your current payoff amount.
          </span>
        </div>
      )}

      {/* Summary Row */}
      <div className="grid grid-cols-3 gap-3">
        <div className="text-center p-3 rounded-md border bg-background">
          <div className={`flex items-center justify-center gap-1 text-xl font-bold ${saving ? "text-green-600 dark:text-green-400" : "text-red-500"}`}>
            {saving ? <TrendingDown className="h-5 w-5" /> : <TrendingUp className="h-5 w-5" />}
            {formatCurrency(Math.abs(result.monthlySavings))}
          </div>
          <p className="text-xs text-muted-foreground mt-0.5">
            {saving ? "Monthly savings" : "Monthly increase"}
          </p>
        </div>

        <div className="text-center p-3 rounded-md border bg-background">
          <div className="flex items-center justify-center gap-1 text-xl font-bold">
            <Clock className="h-5 w-5 text-muted-foreground" />
            {saving && result.breakEvenMonths > 0
              ? `${result.breakEvenMonths} mo`
              : "—"}
          </div>
          <p className="text-xs text-muted-foreground mt-0.5">Break-even point</p>
        </div>

        <div className="text-center p-3 rounded-md border bg-background">
          <div className={`flex items-center justify-center gap-1 text-xl font-bold ${result.totalSavings > 0 ? "text-green-600 dark:text-green-400" : "text-red-500"}`}>
            <DollarSign className="h-5 w-5" />
            {formatCurrency(Math.abs(result.totalSavings))}
          </div>
          <p className="text-xs text-muted-foreground mt-0.5">
            {result.totalSavings > 0 ? "Total interest saved" : "Extra total cost"}
          </p>
        </div>
      </div>


        </div>{/* end Rate & Term content */}
      </div>{/* end Rate & Term card */}

      {/* ── Cash-Out Refinance ── */}
      <div className="rounded-lg border border-green-200 dark:border-green-800 overflow-hidden">
        <div className="flex items-center gap-2 px-4 py-3 bg-green-50 dark:bg-green-950/50 border-b border-green-200 dark:border-green-800">
          <Banknote className="h-4 w-4 text-green-600 dark:text-green-400 flex-shrink-0" />
          <span className="font-semibold text-green-900 dark:text-green-100">Cash-Out Refinance</span>
          <span className="text-xs text-green-600 dark:text-green-400 ml-1 hidden sm:inline">Replace your mortgage and pull equity out</span>
        </div>
        <div className="p-4">
          <CashOutSection loan={loan} newRate={adjustedRate} homeValue={homeValue} onChangeHomeValue={updateHomeValue} />
        </div>
      </div>

      {/* ── 2nd Lien Home Equity ── */}
      <div className="rounded-lg border border-yellow-300 dark:border-yellow-700 overflow-hidden">
        <div className="flex items-center gap-2 px-4 py-3 bg-yellow-50 dark:bg-yellow-950/40 border-b border-yellow-300 dark:border-yellow-700">
          <Landmark className="h-4 w-4 text-yellow-600 dark:text-yellow-400 flex-shrink-0" />
          <span className="font-semibold text-yellow-900 dark:text-yellow-100">2nd Lien Home Equity</span>
          <span className="text-xs text-yellow-600 dark:text-yellow-500 ml-1 hidden sm:inline">Keep your 1st mortgage · tap equity separately</span>
        </div>
        <div className="p-4">
          <HomeEquitySection loan={loan} heRate={heRate} rateAdjustment={rateAdjustment} propertyType={loan.propertyType ?? "primary"} homeValue={homeValue} onChangeHomeValue={updateHomeValue} />
        </div>
      </div>

    </div>
  );
}

function LoanRow({ loan, liveRates, onRemove, onUpdate }: {
  loan: TrackedLoan;
  liveRates: LiveRate[];
  onRemove: () => void;
  onUpdate: (updates: Partial<TrackedLoan>) => void;
}) {
  const [expanded, setExpanded] = useState(false);
  const propertyType = loan.propertyType ?? "primary";
  const rateAdjustment = PROPERTY_TYPE_ADJUSTMENTS[propertyType];

  // Amortize the balance from balanceAsOf (or addedAt) → today
  const balanceAsOf = loan.balanceAsOf ?? loan.addedAt;
  const monthsElapsed = monthsBetween(balanceAsOf);
  const amortizedBalance = Math.round(
    amortizeBalance(loan.loanBalance, loan.currentRate, loan.currentPI, monthsElapsed)
  );
  const adjustedRemainingYears = Math.max(0.5, loan.estimatedRemainingYears - monthsElapsed / 12);

  // Build a "live" snapshot so all children see the up-to-date balance
  const liveLoan: TrackedLoan = {
    ...loan,
    loanBalance: amortizedBalance,
    estimatedRemainingYears: adjustedRemainingYears,
  };

  const bestRate = getBestConventionalRate(liveRates);
  const baseRate = bestRate?.rate ?? 6.45;
  const adjustedTodayRate = parseFloat((baseRate + rateAdjustment).toFixed(3));
  const bestOption = getBestOption(liveLoan, adjustedTodayRate, propertyType);
  const { Icon: BestIcon } = bestOption;

  return (
    <div className={`rounded-lg border transition-colors ${bestOption.cardBg}`} data-testid={`loan-row-${loan.id}`}>
      {/* Clickable expand/collapse header */}
      <button
        className="w-full text-left p-4"
        onClick={() => setExpanded((v) => !v)}
        data-testid={`button-expand-loan-${loan.id}`}
      >
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-start gap-2 min-w-0">
            <MapPin className="h-4 w-4 mt-0.5 flex-shrink-0 text-muted-foreground" />
            <div className="min-w-0">
              <p className="font-semibold text-sm truncate">{loan.propertyAddress}</p>
              <p className="text-xs text-muted-foreground">{loan.lender}</p>
            </div>
          </div>
          <div className="flex items-center gap-1 flex-shrink-0">
            {expanded
              ? <ChevronUp className="h-4 w-4 text-muted-foreground" />
              : <ChevronDown className="h-4 w-4 text-muted-foreground" />}
          </div>
        </div>

        {/* Best option recommendation */}
        <div className="mt-3 ml-6">
          <div className="flex items-center gap-1.5 flex-wrap">
            <Lightbulb className="h-3.5 w-3.5 text-muted-foreground flex-shrink-0" />
            <span className="text-xs text-muted-foreground font-medium uppercase tracking-wide">Best option now</span>
            <span className={`inline-flex items-center gap-1 text-xs font-semibold px-2 py-0.5 rounded-full border ${bestOption.badgeClass}`}>
              <BestIcon className="h-3 w-3" />
              {bestOption.label}
            </span>
          </div>
        </div>
      </button>

      {/* Property type selector — always visible, outside the button */}
      <div
        className="px-4 py-2 border-t flex items-center gap-2 flex-wrap"
        onClick={(e) => e.stopPropagation()}
      >
        <span className="text-xs text-muted-foreground font-medium">Property type:</span>
        {(["primary", "secondary", "investment"] as PropertyType[]).map((type) => {
          const active = propertyType === type;
          return (
            <button
              key={type}
              onClick={() => onUpdate({ propertyType: type })}
              className={`text-xs px-2.5 py-1 rounded-full border font-medium transition-colors ${
                active ? PROPERTY_TYPE_COLORS[type] : "bg-background text-muted-foreground border hover:bg-muted"
              }`}
              data-testid={`button-prop-type-${type}-${loan.id}`}
            >
              {PROPERTY_TYPE_LABELS[type]}
            </button>
          );
        })}
      </div>

      {/* Expanded Content */}
      {expanded && (
        <div className="px-4 pb-4">
          {bestRate ? (
            <ExpandedView loan={liveLoan} newRate={bestRate} rateAdjustment={rateAdjustment} onUpdate={onUpdate} />
          ) : (
            <p className="text-sm text-muted-foreground mt-2">Loading live rates…</p>
          )}
          <div className="mt-4 flex justify-end">
            <Button
              variant="ghost"
              size="sm"
              onClick={(e) => { e.stopPropagation(); onRemove(); }}
              className="text-destructive hover:text-destructive hover:bg-destructive/10"
              data-testid={`button-remove-loan-${loan.id}`}
            >
              <Trash2 className="h-4 w-4 mr-1" />
              Remove from tracker
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}

export function LoanTracker({ loans, liveRates, onRemove, onUpdate, maxLoans = 10 }: LoanTrackerProps) {
  if (loans.length === 0) return null;

  const atLimit = loans.length >= maxLoans;

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between gap-3">
          <CardTitle className="text-base flex items-center gap-2">
            <TrendingDown className="h-5 w-5 text-primary" />
            Loans Being Tracked
          </CardTitle>
          <Badge variant={atLimit ? "destructive" : "secondary"} className="text-xs tabular-nums">
            {loans.length} / {maxLoans}
          </Badge>
        </div>
        {atLimit && (
          <p className="text-xs text-amber-600 dark:text-amber-400 mt-1">
            Tracker is full — remove a loan before adding another.
          </p>
        )}
      </CardHeader>
      <CardContent className="space-y-3">
        {loans.map((loan) => (
          <LoanRow
            key={loan.id}
            loan={loan}
            liveRates={liveRates}
            onRemove={() => onRemove(loan.id)}
            onUpdate={(updates) => onUpdate(loan.id, updates)}
          />
        ))}
        <Separator />
        <p className="text-xs text-muted-foreground">
          Each uploaded statement is automatically added here.
          Expand any loan to see a detailed refinance cost breakdown.
        </p>
      </CardContent>
    </Card>
  );
}
