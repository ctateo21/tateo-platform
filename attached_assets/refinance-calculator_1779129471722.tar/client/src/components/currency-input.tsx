import { forwardRef, useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

interface CurrencyInputProps {
  value: number;
  onChange: (value: number) => void;
  placeholder?: string;
  className?: string;
  "data-testid"?: string;
}

export const CurrencyInput = forwardRef<HTMLInputElement, CurrencyInputProps>(
  ({ value, onChange, placeholder, className, "data-testid": testId }, ref) => {
    const [displayValue, setDisplayValue] = useState("");

    useEffect(() => {
      if (value === 0) {
        setDisplayValue("");
      } else {
        setDisplayValue(formatNumber(value));
      }
    }, [value]);

    const formatNumber = (num: number): string => {
      return num.toLocaleString("en-US");
    };

    const parseNumber = (str: string): number => {
      const cleaned = str.replace(/[^0-9.]/g, "");
      const parsed = parseFloat(cleaned);
      return isNaN(parsed) ? 0 : parsed;
    };

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const rawValue = e.target.value;
      const numericValue = parseNumber(rawValue);
      setDisplayValue(rawValue.replace(/[^0-9.,]/g, ""));
      onChange(numericValue);
    };

    const handleBlur = () => {
      if (value > 0) {
        setDisplayValue(formatNumber(value));
      }
    };

    return (
      <div className="relative">
        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
          $
        </span>
        <Input
          ref={ref}
          type="text"
          inputMode="numeric"
          value={displayValue}
          onChange={handleChange}
          onBlur={handleBlur}
          placeholder={placeholder}
          className={cn("pl-7", className)}
          data-testid={testId}
        />
      </div>
    );
  }
);

CurrencyInput.displayName = "CurrencyInput";
