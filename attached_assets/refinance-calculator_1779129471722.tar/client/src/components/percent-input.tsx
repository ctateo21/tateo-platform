import { forwardRef, useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

interface PercentInputProps {
  value: number;
  onChange: (value: number) => void;
  placeholder?: string;
  className?: string;
  step?: number;
  max?: number;
  "data-testid"?: string;
}

export const PercentInput = forwardRef<HTMLInputElement, PercentInputProps>(
  ({ value, onChange, placeholder, className, step = 0.125, max = 25, "data-testid": testId }, ref) => {
    const [displayValue, setDisplayValue] = useState("");

    useEffect(() => {
      if (value === 0) {
        setDisplayValue("");
      } else {
        setDisplayValue(value.toString());
      }
    }, [value]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const rawValue = e.target.value;
      const cleaned = rawValue.replace(/[^0-9.]/g, "");
      setDisplayValue(cleaned);
      
      const parsed = parseFloat(cleaned);
      if (!isNaN(parsed) && parsed <= max) {
        onChange(parsed);
      } else if (cleaned === "") {
        onChange(0);
      }
    };

    const handleBlur = () => {
      if (value > 0) {
        setDisplayValue(value.toFixed(3).replace(/\.?0+$/, ""));
      }
    };

    return (
      <div className="relative">
        <Input
          ref={ref}
          type="text"
          inputMode="decimal"
          value={displayValue}
          onChange={handleChange}
          onBlur={handleBlur}
          placeholder={placeholder}
          className={cn("pr-7", className)}
          data-testid={testId}
        />
        <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">
          %
        </span>
      </div>
    );
  }
);

PercentInput.displayName = "PercentInput";
