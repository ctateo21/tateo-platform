import { z } from "zod";

export const refinanceTypeSchema = z.enum(["rate_and_term", "cash_out"]);
export type RefinanceType = z.infer<typeof refinanceTypeSchema>;

export const refinanceInputSchema = z.object({
  appraisedValue: z.number().min(1, "Appraised value must be greater than 0"),
  loanBalance: z.number().min(1, "Loan balance must be greater than 0"),
  currentInterestRate: z.number().min(0.01, "Current rate must be greater than 0").max(25, "Rate cannot exceed 25%"),
  newInterestRate: z.number().min(0.01, "New rate must be greater than 0").max(25, "Rate cannot exceed 25%"),
  currentTermRemainingYears: z.number().min(1).max(40),
  newLoanTermYears: z.number().min(5).max(40),
  closingCostsPercent: z.number().min(0).max(10),
  closingCostsFixed: z.number().min(0),
  includeClosingCostsInLoan: z.boolean(),
  refinanceType: refinanceTypeSchema,
  cashOutAmount: z.number().min(0).optional(),
});

export type RefinanceInput = z.infer<typeof refinanceInputSchema>;

export interface RefinanceResult {
  newLoanAmount: number;
  totalClosingCosts: number;
  monthlyPaymentCurrent: number;
  monthlyPaymentNew: number;
  monthlySavings: number;
  totalInterestCurrent: number;
  totalInterestNew: number;
  totalSavings: number;
  breakEvenMonths: number;
  ltvRatio: number;
  cashOutAvailable: number;
  cashOutExceedsMax: boolean;
}

export interface LiveRate {
  name: string;
  rate: number;
  change: number;
  type: string;
  lastUpdated: string;
}

export interface LiveRatesResponse {
  rates: LiveRate[];
  source: string;
  disclaimer: string;
  asOf: string;
}

export interface MortgageAnalysis {
  loanBalance: number;
  interestRate: number;
  monthlyPayment: number;
  principalAndInterest: number;
  escrowAmount: number;
  propertyAddress: string;
  lender: string;
  estimatedRemainingYears: number;
  estimatedHomeValue: number;
  confidence: "high" | "medium" | "low";
  recommendation: string;
  potentialSavings: number;
  rawExtractedData: Record<string, string | number>;
}

export type PropertyType = "primary" | "secondary" | "investment";

export interface TrackedLoan {
  id: string;
  propertyAddress: string;
  lender: string;
  loanBalance: number;
  currentRate: number;
  currentPI: number;
  monthlyPayment: number;
  estimatedHomeValue: number;
  estimatedRemainingYears: number;
  addedAt: string;
  balanceAsOf?: string;   // ISO date when loanBalance was last accurate; defaults to addedAt
  propertyType: PropertyType;
}

export interface User {
  id: number;
  username: string;
  email: string;
  phone: string;
  createdAt: string;
}

export const registerSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters").max(50).regex(/^[a-zA-Z0-9_]+$/, "Username can only contain letters, numbers, and underscores"),
  email: z.string().email("Invalid email address"),
  phone: z.string().min(7, "Phone number is too short").max(20),
  password: z.string().min(8, "Password must be at least 8 characters"),
});

export const loginSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
});

export type RegisterInput = z.infer<typeof registerSchema>;
export type LoginInput = z.infer<typeof loginSchema>;

export interface AnalyzeStatementRequest {
  documentText: string;
}

export interface AnalyzeStatementResponse {
  success: boolean;
  analysis?: MortgageAnalysis;
  error?: string;
}
