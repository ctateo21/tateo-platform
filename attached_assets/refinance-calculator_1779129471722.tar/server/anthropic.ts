import Anthropic from "@anthropic-ai/sdk";
import type { MortgageAnalysis } from "@shared/schema";

// the newest Anthropic model is "claude-opus-4-5" which was released in 2025
const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

export async function analyzeMortgageStatement(documentText: string): Promise<MortgageAnalysis> {
  const systemPrompt = `You are a mortgage document analyzer. Extract key information from mortgage statements and provide refinancing recommendations.

You must respond with a valid JSON object containing the following fields:
- loanBalance: number (the unpaid principal balance - extract exactly from document)
- interestRate: number (the current interest rate as a decimal, e.g., 4.875 for 4.875% - extract exactly from document)
- monthlyPayment: number (total monthly payment including escrow)
- principalAndInterest: number (just the P&I portion without escrow)
- escrowAmount: number (taxes and insurance portion)
- propertyAddress: string (full property address as shown in document)
- lender: string (the mortgage servicer/lender name)
- estimatedRemainingYears: number (estimate based on loan balance, rate, and P&I payment using amortization formula: n = -ln(1 - (r*P)/M) / ln(1+r) where r is monthly rate, P is principal, M is monthly P&I payment, then divide by 12 for years)
- estimatedHomeValue: number (estimate the current market value of the property. First, look for any appraisal value, assessed value, or property value mentioned anywhere in the document. If found, use that. If not found, use your knowledge of the property type and location to estimate a reasonable market value — for condos in Florida, use current market conditions which may differ significantly from purchase price. As a last resort only, back-calculate from loanBalance / 0.75, but only if no better estimate is available. Note: a 75% LTV back-calculation on an existing mortgage with years of payments will consistently OVERESTIMATE home value)
- confidence: "high" | "medium" | "low" (high if you found exact values for balance, rate, and payment; medium if some estimation needed; low if major values are guessed)
- recommendation: string (compare extracted rate to current market rates of 6.5-7% for 30-year fixed. If current rate is BELOW market rates, recommend keeping current loan. If ABOVE market rates, recommend refinancing and explain the potential benefit)
- potentialSavings: number (if refinancing is recommended, estimate monthly savings by calculating the difference between current P&I payment and what P&I would be at 6.5%. If not recommended, use 0)
- rawExtractedData: object with any other relevant fields you found in the document

Be precise with extracted values - do not round or estimate values that are clearly stated in the document. Only estimate when values are not available.

Respond with a JSON object only, no additional text.`;

  const response = await anthropic.messages.create({
    model: "claude-opus-4-5",
    max_tokens: 2048,
    system: systemPrompt,
    messages: [
      {
        role: "user",
        content: `Analyze this mortgage statement and extract all relevant information:\n\n${documentText}`,
      },
    ],
  });

  const content = response.content[0];
  if (content.type !== "text") {
    throw new Error("No response from AI");
  }

  // Strip any markdown code fences if present
  const raw = content.text.trim().replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "");
  const analysis = JSON.parse(raw) as MortgageAnalysis;
  return analysis;
}
