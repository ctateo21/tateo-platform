import pg from "pg";
import bcrypt from "bcrypt";
import type { User, RegisterInput } from "@shared/schema";

const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL });

export async function createUser(input: RegisterInput): Promise<User> {
  const passwordHash = await bcrypt.hash(input.password, 12);
  const result = await pool.query(
    `INSERT INTO users (username, email, phone, password_hash)
     VALUES ($1, $2, $3, $4)
     RETURNING id, username, email, phone, created_at`,
    [input.username.toLowerCase(), input.email.toLowerCase(), input.phone, passwordHash]
  );
  const row = result.rows[0];
  return { id: row.id, username: row.username, email: row.email, phone: row.phone, createdAt: row.created_at };
}

export async function getUserByUsername(username: string): Promise<(User & { passwordHash: string }) | null> {
  const result = await pool.query(
    `SELECT id, username, email, phone, password_hash, created_at FROM users WHERE username = $1`,
    [username.toLowerCase()]
  );
  if (result.rows.length === 0) return null;
  const row = result.rows[0];
  return { id: row.id, username: row.username, email: row.email, phone: row.phone, createdAt: row.created_at, passwordHash: row.password_hash };
}

export async function getUserById(id: number): Promise<User | null> {
  const result = await pool.query(
    `SELECT id, username, email, phone, created_at FROM users WHERE id = $1`,
    [id]
  );
  if (result.rows.length === 0) return null;
  const row = result.rows[0];
  return { id: row.id, username: row.username, email: row.email, phone: row.phone, createdAt: row.created_at };
}

export async function usernameExists(username: string): Promise<boolean> {
  const result = await pool.query(`SELECT 1 FROM users WHERE username = $1`, [username.toLowerCase()]);
  return result.rows.length > 0;
}

export async function emailExists(email: string): Promise<boolean> {
  const result = await pool.query(`SELECT 1 FROM users WHERE email = $1`, [email.toLowerCase()]);
  return result.rows.length > 0;
}

export async function verifyPassword(plain: string, hash: string): Promise<boolean> {
  return bcrypt.compare(plain, hash);
}
