import type { Express, Request, Response, NextFunction } from "express";
import type { Server } from "http";
import multer from "multer";
import session from "express-session";
import ConnectPgSimple from "connect-pg-simple";
import pg from "pg";
import type { AnalyzeStatementResponse } from "@shared/schema";
import { registerSchema, loginSchema } from "@shared/schema";
import { analyzeMortgageStatement } from "./anthropic";
import { getLiveRates } from "./rates-scraper";
import { createUser, getUserByUsername, getUserById, usernameExists, emailExists, verifyPassword } from "./storage";
import { createFUBLead } from "./followupboss";

declare module "express-session" {
  interface SessionData {
    userId: number;
  }
}

const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 }
});

function requireAuth(req: Request, res: Response, next: NextFunction) {
  if (!req.session.userId) {
    res.status(401).json({ error: "Not authenticated" });
    return;
  }
  next();
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  const PgSession = ConnectPgSimple(session);
  const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL });

  app.use(session({
    store: new PgSession({ pool, createTableIfMissing: true }),
    secret: process.env.SESSION_SECRET || "fallback-secret-change-me",
    resave: false,
    saveUninitialized: false,
    cookie: {
      maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
      httpOnly: true,
      secure: false,
    }
  }));

  // ── Auth routes ──

  app.post("/api/auth/register", async (req, res) => {
    const parsed = registerSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.errors[0].message });
      return;
    }
    const { username, email, phone, password } = parsed.data;

    if (await usernameExists(username)) {
      res.status(409).json({ error: "Username is already taken" });
      return;
    }
    if (await emailExists(email)) {
      res.status(409).json({ error: "An account with that email already exists" });
      return;
    }

    const user = await createUser({ username, email, phone, password });
    req.session.userId = user.id;

    // Fire-and-forget — don't block registration if FUB is slow or down
    createFUBLead({ username: user.username, email, phone }).catch((err) =>
      console.error("FUB lead creation error:", err)
    );

    res.json({ user });
  });

  app.post("/api/auth/login", async (req, res) => {
    const parsed = loginSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.errors[0].message });
      return;
    }
    const { username, password } = parsed.data;
    const found = await getUserByUsername(username);
    if (!found || !(await verifyPassword(password, found.passwordHash))) {
      res.status(401).json({ error: "Invalid username or password" });
      return;
    }
    req.session.userId = found.id;
    const { passwordHash: _, ...user } = found;
    res.json({ user });
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy(() => {
      res.json({ ok: true });
    });
  });

  app.get("/api/auth/me", async (req, res) => {
    if (!req.session.userId) {
      res.status(401).json({ user: null });
      return;
    }
    const user = await getUserById(req.session.userId);
    if (!user) {
      res.status(401).json({ user: null });
      return;
    }
    res.json({ user });
  });

  // ── Existing routes (protected) ──

  app.get("/api/rates", async (req, res) => {
    try {
      const rates = await getLiveRates();
      res.json(rates);
    } catch (err) {
      console.error("Error fetching rates:", err);
      res.status(500).json({ error: "Failed to fetch rates" });
    }
  });

  app.post("/api/analyze-statement", requireAuth, upload.single("file"), async (req, res) => {
    try {
      let documentText = "";

      if (req.file) {
        if (req.file.mimetype === "application/pdf") {
          const { PDFParse } = await import("pdf-parse");
          const pdfParser = new PDFParse({ data: req.file.buffer });
          const pdfData = await pdfParser.getText();
          documentText = pdfData.text;
        } else if (req.file.mimetype.startsWith("text/")) {
          documentText = req.file.buffer.toString("utf-8");
        } else {
          res.status(400).json({ 
            success: false, 
            error: "Unsupported file type. Please upload a PDF or text file." 
          } as AnalyzeStatementResponse);
          return;
        }
      } else if (req.body.documentText) {
        documentText = req.body.documentText;
      } else {
        res.status(400).json({ 
          success: false, 
          error: "Please upload a file or provide document text." 
        } as AnalyzeStatementResponse);
        return;
      }

      if (!process.env.ANTHROPIC_API_KEY) {
        res.status(500).json({ 
          success: false, 
          error: "Anthropic API key not configured." 
        } as AnalyzeStatementResponse);
        return;
      }

      const analysis = await analyzeMortgageStatement(documentText);
      res.json({ success: true, analysis } as AnalyzeStatementResponse);
    } catch (error) {
      console.error("Error analyzing statement:", error);
      res.status(500).json({ 
        success: false, 
        error: error instanceof Error ? error.message : "Failed to analyze statement" 
      } as AnalyzeStatementResponse);
    }
  });

  return httpServer;
}
