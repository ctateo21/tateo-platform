interface FUBPersonPayload {
  username: string;
  email: string;
  phone: string;
}

export async function createFUBLead({ username, email, phone }: FUBPersonPayload): Promise<void> {
  const apiKey = process.env.FOLLOWUPBOSS_API_KEY;
  if (!apiKey) {
    console.warn("FOLLOWUPBOSS_API_KEY not set — skipping FUB lead creation");
    return;
  }

  const credentials = Buffer.from(`${apiKey}:`).toString("base64");

  const body = {
    source: "Replit Refinance",
    firstName: username,
    emails: [{ value: email, type: "work" }],
    phones: [{ value: phone, type: "mobile" }],
  };

  const res = await fetch("https://api.followupboss.com/v1/people", {
    method: "POST",
    headers: {
      "Authorization": `Basic ${credentials}`,
      "Content-Type": "application/json",
      "X-System": "Refinance Dashboard",
      "X-System-Key": apiKey,
    },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const text = await res.text();
    console.error(`FUB lead creation failed (${res.status}):`, text);
  } else {
    const data = await res.json();
    console.log(`FUB lead created — id: ${data.id}, email: ${email}`);
  }
}
