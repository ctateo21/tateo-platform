# Refinance Calculator

A mortgage refinance calculator application that helps users estimate savings when refinancing their mortgage. Supports both rate-and-term and cash-out refinance options, with AI-powered mortgage statement analysis.

## Overview

This application allows users to:
- **AI Statement Analyzer**: Upload a mortgage statement (PDF) or paste text to automatically extract loan details
- Input their current mortgage details (appraised value, loan balance, interest rate)
- Choose between Rate & Term or Cash-Out refinance types
- Configure closing costs (percentage and/or fixed amount)
- Roll closing costs into the new loan
- View live rates (placeholder for integration with live rate provider)
- See detailed results including monthly savings, break-even analysis, and LTV ratio

## Project Architecture

### Frontend (client/)
- **client/src/pages/calculator.tsx** - Main calculator page with form inputs and results display
- **client/src/components/** - Reusable UI components:
  - `statement-analyzer.tsx` - AI-powered mortgage statement analyzer with file upload
  - `currency-input.tsx` - Formatted currency input with $ prefix
  - `percent-input.tsx` - Percentage input with % suffix
  - `results-card.tsx` - Displays calculation results with visual indicators
  - `live-rates-card.tsx` - Shows available rates from API (placeholder)
  - `theme-toggle.tsx` - Dark/light mode toggle
- **client/src/lib/calculations.ts** - Core refinance calculation logic

### Backend (server/)
- **server/routes.ts** - API endpoints:
  - `GET /api/rates` - Returns sample mortgage rates (placeholder for live rate provider integration)
  - `POST /api/analyze-statement` - Analyzes uploaded mortgage statement using Anthropic Claude
- **server/anthropic.ts** - Anthropic Claude integration for document analysis

### Shared (shared/)
- **shared/schema.ts** - TypeScript types and Zod schemas for:
  - `RefinanceInput` - User input data
  - `RefinanceResult` - Calculation output
  - `LiveRate` / `LiveRatesResponse` - Rate data structure
  - `MortgageAnalysis` - AI-extracted mortgage data

## Key Features

### AI Statement Analyzer
- Upload PDF mortgage statements or paste text
- Extracts: loan balance, interest rate, monthly payment, lender, property address
- Estimates: remaining term, home value
- Provides refinancing recommendation based on current market rates
- Auto-populates calculator with extracted values

### Rate & Term Refinance
- Lower monthly payment by reducing interest rate
- Change loan term (10, 15, 20, 25, 30 years)
- Shows break-even point for closing costs

### Cash-Out Refinance
- Access home equity
- Shows maximum cash-out available (80% LTV limit)
- Includes cash-out amount in new loan balance
- Warns when cash-out exceeds maximum

### Closing Costs
- Configurable percentage of loan (typically 2-5%)
- Fixed cost option for known fees
- Toggle to roll into loan or pay upfront

### Live Rates Integration
The `/api/rates` endpoint scrapes live rates from MortgageNewsDaily.com using cheerio:
- **server/rates-scraper.ts** - Scrapes MND's `.rate-product` blocks with cheerio; caches results for 15 minutes; falls back to stale cache or hardcoded estimates on failure
- Rates fetched: 30 Yr. Fixed (Conventional), 15 Yr. Fixed (Conventional), 30 Yr. Jumbo, 7/6 SOFR ARM, 30 Yr. FHA, 30 Yr. VA
- Each rate includes name, current rate %, daily change, and loan type

## Live Balance Amortization

Each tracked loan stores a `balanceAsOf` timestamp (set when the loan is first added or when the user manually corrects the balance). Every time `LoanRow` renders, it computes the exact number of full months between `balanceAsOf` and today using `monthsBetween()`, then applies the standard amortization formula via `amortizeBalance()` to derive the current principal balance. The adjusted balance and remaining term are passed to all child components (`getBestOption`, `ExpandedView`, all three scenario sections) via a `liveLoan` object.

In the expanded "Current Loan" card, the Loan Balance row shows a blue "~Nmo paydown applied" indicator when months have elapsed. A pencil icon opens an inline edit field so the user can enter the actual balance from their latest statement. Saving writes `{ loanBalance: X, balanceAsOf: today }` back to localStorage, which resets the amortization clock from today forward.

Key functions:
- `amortizeBalance(balance, annualRatePct, monthlyPI, months)` in `client/src/lib/calculations.ts`
- `monthsBetween(fromISO)` in `client/src/lib/calculations.ts`

## Authentication

Users must create an account to access the dashboard. Auth is session-based using PostgreSQL-backed sessions.

- **Register**: Username (letters/numbers/underscores, 3–50 chars), email, phone, password (min 8 chars)
- **Login**: Username + password; session persists 7 days
- **Routes**: `/login`, `/register` are public; `/` is protected (redirects to `/login` if not authenticated)
- **Backend**: `server/storage.ts` — CRUD using `pg` pool; passwords hashed with bcrypt (12 rounds)
- **Sessions**: `express-session` + `connect-pg-simple` (auto-creates `session` table)
- **Frontend**: `client/src/hooks/use-auth.tsx` — React context with `user`, `login()`, `logout()`, `refetch()`

## Database

- PostgreSQL (Replit built-in)
- Tables: `users` (id, username, email, phone, password_hash, created_at), `session` (auto-created by connect-pg-simple)

## Environment Variables

- `ANTHROPIC_API_KEY` - Required for AI statement analysis feature
- `SESSION_SECRET` - Required for session cookie signing
- `DATABASE_URL` - PostgreSQL connection string (auto-set by Replit)

## Development

- **Start**: `npm run dev` - Runs both frontend (Vite) and backend (Express)
- **Frontend**: React + TypeScript + TailwindCSS + shadcn/ui
- **Backend**: Express.js with multer for file uploads
- **AI**: Anthropic claude-opus-4-5 for document analysis
- **State**: In-memory (no database required for calculator)

## Design System

- Primary color: Blue (#2563eb)
- Professional financial theme
- Dark mode support
- Responsive design (mobile-first)
